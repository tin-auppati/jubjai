# 24cs212g12 จิ๊ดริด

## Team: (24cs212g12)  
### Project: 8 บันทึกค่าใช้จ่าย
**Group ID:** 24cs212g12  
**Mentor:** ศรันธ์ จตุพรพิทักษ์กุล (พี่ต้าร์)

### Tech Stack:
- **Frontend:** Flask
- **Backend:** Flask  
### Members:

#### 1. ติณห์ อุปติ
- **Student ID:** 660510650  
- **GitHub ID:** [tin-auppati](https://github.com/tin-auppati)  
- **Role:** Not specified

#### 2. วุฒิภัทร ถิ่นหลวง
- **Student ID:** 660510677  
- **GitHub ID:** [pheeet](https://github.com/pheeet)  
- **Role:** Not specified 

#### 3. กมลภู อุตรพงศ์
- **Student ID:** 660510688  
- **GitHub ID:** [k-092](https://github.com/k-092)  
- **Role:** Not specified  

#### 4. สุชานันท์ อ่อนศรีประไพ
- **Student ID:** 660510729  
- **GitHub ID:** [miyu-yumi](https://github.com/miyu-yumi)  
- **Role:** Not specified  

---

### Notes:
- Note  
